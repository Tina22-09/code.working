#def funtion_name(parameters)

def FancyText(symbol):
  text= input("please enter a text: ")
  print(symbol*(len(text)+4))
  print(symbol + " "+ text + " " + symbol)
  print(symbol*(len(text)+4))

FancyText("*")
FancyText("@")

print("END OF PROGRAM")