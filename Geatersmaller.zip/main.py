num1 =int(input("enter your number here: "))
num2 = int(input("enter your number here: "))
num3 = int(input("enter your number here: "))
number=[]
number.append(num1)
number.append(num2)
number.append(num3)
print(number)
average= sum(number)/len(number)
print("The average is",average)


