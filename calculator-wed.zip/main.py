while True:

#take the input from the user
  num1 = int(input("enter the first number here: "))
  num2 = int(input("enter your second number here: "))
  #take the operator
  operator = input("operator(+,-,/,*): ")

  if operator == "+": 
    answer= num1 + num2
  elif operator == "-":
    answer= num1 - num2
  elif operator == "/":
    answer= num1/num2
  elif operator == "*":
    answer= num1*num2
  else:
    print("Enter a valid operator and try again")

  print("Answer:",answer)

  end = input("Do you want  to continue?: ")
  if end == "yes":
    continue 
  if end == "no":
    break