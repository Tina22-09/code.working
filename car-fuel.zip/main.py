print("Calculate the miles per gallon")

miles_driven = int(input("Enter number of miles driven: "))
gallons_of_fuel_used = int(input("Enter gallons of fuel used: "))
mpg = miles_driven / gallons_of_fuel_used 

print('Miles per gallon =', mpg)
 
print("Calculate the miles for BMW" )
mpg = 36
gallons_of_fuel_used = int(input ("enter the gallons of fuel used: "))
miles_driven = gallons_of_fuel_used * mpg 
print("The miles driven by the BMW is" ,miles_driven)