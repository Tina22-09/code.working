num1= int(input("enter the number here: "))
num2= int(input("entr the number here: "))

if (num1 > num2 ):
  print(num1 , "is greater than", num2 )
else :
  print(num1, "is smaller than", num2)



word1 = input("enter your word here: ")
word2 = input("enter your word here: ")

if (word1 > word2):
  print(word1, "is greater than", word2)
else:
  print(word1, "is smaller than", word2)


